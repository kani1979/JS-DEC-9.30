function doRest(...args:any[])
{
    console.log(args);
}

doRest("hi");

doRest("hi", "hello", 88);

doRest("hi", "welcome", "good", "morning");