var str : string = "hello";

var num : number;

num = 89; num = 100;

var isMatch = true;

isMatch = false;

var xyz:any;

xyz = 12; xyz = true;

var msg : number | string;

msg = 44; msg = "hi";



