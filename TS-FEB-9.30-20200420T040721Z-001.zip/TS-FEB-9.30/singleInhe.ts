class DailyWish {

    msg : string;
    wish : string;

    constructor(m:string, w:string)
    {
        this.msg = m;
        this.wish = w;

    }

    dailywish()
    {
        console.log(`${this.msg}, ${this.wish}`);
    }

}

class FestivalWish extends DailyWish {

    msg2 = this.msg;
    msg = "Hello";

    fWish : string;

    constructor(fw:string)
    {
        super("Hey", "Good Morning!");

        this.fWish = fw;
    }

    dailywish()
    {
        console.log("Hello All");
    }

    festiveWish()
    {
        super.dailywish();
        console.log(`${this.msg2}, ${this.fWish}`)
    }
}

var fw = new FestivalWish("Happy New Year!");

//fw.dailywish();
fw.festiveWish();