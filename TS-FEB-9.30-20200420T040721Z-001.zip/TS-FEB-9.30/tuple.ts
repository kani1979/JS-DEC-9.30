var tu : [number, string] = [0, ''];

tu.unshift("hi");

console.log(tu);