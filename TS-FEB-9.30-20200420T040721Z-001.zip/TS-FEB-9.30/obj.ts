var obj = {name:"gopi", age:55};

//obj.place = "dfdfdd";

var person : {fname:string, lname:string, age?:number} = {fname:"gopi", lname:"kris"};

person.age = 12;


var obj2 : {[key:string] : any} = {};

obj2.a = "hi"; obj2.b = "hello";

obj2.c = 12;

