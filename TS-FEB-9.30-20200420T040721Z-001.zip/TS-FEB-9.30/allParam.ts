function allParam(a:string, b="hello", c?:number, ...d:any[])
{

}

allParam("hello");