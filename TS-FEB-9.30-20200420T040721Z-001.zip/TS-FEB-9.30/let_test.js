function letTest() {
    var y = "hi";
    if (true) {
        var y_1 = "hello";
        console.log(y_1);
    }
    console.log(y);
}
letTest();
