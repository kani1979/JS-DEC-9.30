function dotest():void
{
   console.log("test");
}

console.log(dotest());


