interface if1 {
    fname:string;
    lname:string;

    age?:number;
}

interface if2 {
    place:string;

    getUserDetails?():void;
}

class PersonDetails implements if1, if2 {

    fname = "gopi";

    lname = "kris";

   place = "chennai";
}

function greetUser(user:if1)
{
    console.log(user.fname);
}

var obj = {fname:"gopi", lname:"kris"};

greetUser(obj);