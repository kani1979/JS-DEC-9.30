class ReadOnly {

    readonly gameLevel : string = "100 laps";

    static readonly gamePoint : number = 250;

    constructor()
    {
        this.gameLevel = "200 laps";

    }


}

var ro = new ReadOnly();

console.log(ro.gameLevel);

console.log(ReadOnly.gamePoint);