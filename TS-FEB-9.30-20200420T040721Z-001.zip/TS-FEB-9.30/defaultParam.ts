function greetUser(fname:string, lname="Kris", age:number)
{

    if(lname)
    {
        console.log(`Welcome ${fname} ${lname}`);
    }
    else {
        console.log(`Welcome ${fname}`);

    }
   
}

greetUser("Gopi", "krishna", 66);

greetUser("Bala", undefined, 99);