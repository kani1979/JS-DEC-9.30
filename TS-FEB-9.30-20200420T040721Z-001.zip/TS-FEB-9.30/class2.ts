class Person {

    fname: string;
    lname: string;

    constructor(public firstname:string, public lastname:string)
    {
        this.fname = firstname;
        this.lname = lastname;

    }

    fullname()
    {
        return this.fname+" "+this.lname;
    }
}

var p1 = new Person("Bala", "kumar");

p1.fname = "Arun";

console.log(p1.firstname);

//p1.fname = "Gopi"; p1.lname = "Kris";

console.log(p1.fullname());