var arr1 = ["hi", "hello"];

var arr2 : number[];

arr2 = [];


arr2.push(20);

console.log(arr2);

var arr3 : (string | number)[] = [];

arr3.push("hi", 22);

var arr4 : any[] = [];
