enum hobbies {cricket, chess=100, football="myfav"};


console.log(hobbies);

