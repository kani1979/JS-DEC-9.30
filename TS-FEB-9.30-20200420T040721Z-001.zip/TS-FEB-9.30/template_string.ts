var fname = "gopi";

var lname = "kris";

//console.log("firstname is "+fname+"\n and lastname is "+lname);

console.log(`firstname is ${fname} 

and lastname is ${lname}`);