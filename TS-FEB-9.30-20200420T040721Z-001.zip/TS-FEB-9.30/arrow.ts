var doAdd = (x:number, y:number)=> x+y;


console.log(doAdd(2, 3));