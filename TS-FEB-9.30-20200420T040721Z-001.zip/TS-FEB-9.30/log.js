console.log("welcome to my 1st TypeScript");
