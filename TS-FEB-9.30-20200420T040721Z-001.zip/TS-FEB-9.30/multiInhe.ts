class Semester1 {

    stdName : string;
    js : number;
    ts : number;

    private pvtPro = "Private";

    protected constructor(name:string, javascript:number, typescript:number)
    {
        this.stdName = name;
        this.js = javascript;
        this.ts = typescript;
    }

   protected getTotal()
    {
        return 200;
    }

    getObtainedMarks()
    {
        return this.js+this.ts;
    }
}

class Semester2 extends Semester1 {

    angular : number;
    node : number;

    constructor(name:string, js:number, ts:number, ang:number, node:number)
    {
        super(name, js, ts);

        this.angular = ang;
        this.node = node;
    }

    getTotal()
    {
      //  console.log(this.pvtPro);

        return super.getTotal()+200;
    }

    getObtainedMarks()
    {
        return super.getObtainedMarks()+this.angular+this.node;
    }
}

class Result extends Semester2 {

    findPercentage(om:number, tm:number)
    {
        return om/tm*100;
    }
}

var std1 = new Result("Gopi", 77, 56, 89, 47);

std1.node = 67;

//var sem1 = new Semester1("bala", 88, 55);
//sem1.getTotal();

var std1Percentage = std1.findPercentage(std1.getObtainedMarks(), std1.getTotal());

console.log(std1Percentage);