class MyClass {

    username : string = "Gopi";

    constructor()
    {
        console.log("Object created");
    }

    greetUser()
    {
        console.log("Welcome All");
    }
}

var obj1 = new MyClass();

console.log(obj1.username);

obj1.greetUser();