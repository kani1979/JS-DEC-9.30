function greetUser(fname:string, lname?:string)
{

    if(lname)
    {
        console.log(`Welcome ${fname} ${lname}`);
    }
    else {
        console.log(`Welcome ${fname}`);

    }
   
}

greetUser("Gopi", "Kris");

greetUser("Bala");